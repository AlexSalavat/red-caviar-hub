export default function Manufacturers(){
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Производители</h1>
      <div className="glass p-4 border border-[var(--border)] rounded-2xl text-sm" style={{color:"var(--muted)"}}>
        Раздел в разработке. Здесь будет витрина производителей с фильтрами и метками сертификации.
      </div>
    </div>
  );
}
